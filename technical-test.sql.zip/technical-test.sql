-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 22, 2020 at 10:38 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `technical-test`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `from` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `expert_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `books_expert_id_foreign` (`expert_id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `from`, `to`, `type`, `expert_id`, `created_at`, `updated_at`) VALUES
(1, '3:00:00 PM', '3:15:00 PM', 15, 3, '2020-10-22 08:37:34', '2020-10-22 08:37:34'),
(2, '3:15:00 PM', '3:30:00 PM', 15, 3, '2020-10-22 08:37:34', '2020-10-22 08:37:34'),
(3, '3:30:00 PM', '3:45:00 PM', 15, 3, '2020-10-22 08:37:34', '2020-10-22 08:37:34'),
(4, '3:45:00 PM', '4:00:00 PM', 15, 3, '2020-10-22 08:37:34', '2020-10-22 08:37:34'),
(5, '3:00:00 PM', '3:30:00 PM', 30, 3, '2020-10-22 08:37:34', '2020-10-22 08:37:34'),
(6, '3:30:00 PM', '4:00:00 PM', 30, 3, '2020-10-22 08:37:34', '2020-10-22 08:37:34'),
(7, '3:00:00 PM', '4:00:00 PM', 60, 3, '2020-10-22 08:37:34', '2020-10-22 08:37:34'),
(8, '5:00:00 AM', '5:15:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(9, '5:15:00 AM', '5:30:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(10, '5:30:00 AM', '5:45:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(11, '5:45:00 AM', '6:00:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(12, '6:00:00 AM', '6:15:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(13, '6:15:00 AM', '6:30:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(14, '6:30:00 AM', '6:45:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(15, '6:45:00 AM', '7:00:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(16, '7:00:00 AM', '7:15:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(17, '7:15:00 AM', '7:30:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(18, '7:30:00 AM', '7:45:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(19, '7:45:00 AM', '8:00:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(20, '8:00:00 AM', '8:15:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(21, '8:15:00 AM', '8:30:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(22, '8:30:00 AM', '8:45:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(23, '8:45:00 AM', '9:00:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(24, '9:00:00 AM', '9:15:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(25, '9:15:00 AM', '9:30:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(26, '9:30:00 AM', '9:45:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(27, '9:45:00 AM', '10:00:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(28, '10:00:00 AM', '10:15:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(29, '10:15:00 AM', '10:30:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(30, '10:30:00 AM', '10:45:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(31, '10:45:00 AM', '11:00:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(32, '11:00:00 AM', '11:15:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(33, '11:15:00 AM', '11:30:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(34, '11:30:00 AM', '11:45:00 AM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(35, '11:45:00 AM', '12:00:00 PM', 15, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(36, '5:00:00 AM', '5:30:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(37, '5:30:00 AM', '6:00:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(38, '6:00:00 AM', '6:30:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(39, '6:30:00 AM', '7:00:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(40, '7:00:00 AM', '7:30:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(41, '7:30:00 AM', '8:00:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(42, '8:00:00 AM', '8:30:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(43, '8:30:00 AM', '9:00:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(44, '9:00:00 AM', '9:30:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(45, '9:30:00 AM', '10:00:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(46, '10:00:00 AM', '10:30:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(47, '10:30:00 AM', '11:00:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(48, '11:00:00 AM', '11:30:00 AM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(49, '11:30:00 AM', '12:00:00 PM', 30, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(50, '5:00:00 AM', '6:00:00 AM', 60, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(51, '6:00:00 AM', '7:00:00 AM', 60, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(52, '7:00:00 AM', '8:00:00 AM', 60, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(53, '8:00:00 AM', '9:00:00 AM', 60, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(54, '9:00:00 AM', '10:00:00 AM', 60, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(55, '10:00:00 AM', '11:00:00 AM', 60, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33'),
(56, '11:00:00 AM', '12:00:00 PM', 60, 2, '2020-10-22 10:58:33', '2020-10-22 10:58:33');

-- --------------------------------------------------------

--
-- Table structure for table `book_approves`
--

DROP TABLE IF EXISTS `book_approves`;
CREATE TABLE IF NOT EXISTS `book_approves` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `expert_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `book_approves_user_id_foreign` (`user_id`),
  KEY `book_approves_expert_id_foreign` (`expert_id`),
  KEY `book_approves_book_id_foreign` (`book_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `book_approves`
--

INSERT INTO `book_approves` (`id`, `date`, `user_id`, `expert_id`, `book_id`, `created_at`, `updated_at`) VALUES
(1, '2020-10-21', 1, 3, 1, '2020-10-22 12:27:33', '2020-10-22 12:27:33'),
(2, '2020-10-14', 1, 3, 6, '2020-10-22 18:30:32', '2020-10-22 18:30:32'),
(3, '2020-10-16', 1, 3, 5, '2020-10-22 19:15:05', '2020-10-22 19:15:05'),
(4, '2020-10-16', 1, 2, 45, '2020-10-22 19:15:25', '2020-10-22 19:15:25'),
(5, '2020-10-23', 1, 2, 21, '2020-10-22 19:15:36', '2020-10-22 19:15:36');

-- --------------------------------------------------------

--
-- Table structure for table `experts`
--

DROP TABLE IF EXISTS `experts`;
CREATE TABLE IF NOT EXISTS `experts` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expert` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `working_hours_from` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `working_hours_to` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `experts`
--

INSERT INTO `experts` (`id`, `name`, `expert`, `country`, `working_hours_from`, `working_hours_to`, `timezone`, `created_at`, `updated_at`) VALUES
(2, 'nazar ahmad', 'civil engineer', 'syria', '05:00:00 AM', '12:00:00 PM', 'GMT+3', '2020-10-21 17:20:00', '2020-10-21 17:20:00'),
(3, 'hoda ahmad', 'computer engineer', 'egypt', '03:00:00 PM', '04:00:00 PM', 'GMT+2', '2020-10-21 17:20:28', '2020-10-21 17:20:28');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2020_10_21_121116_create_experts_table', 1),
(6, '2020_10_22_100924_create_books_table', 2),
(7, '2020_10_22_134546_create_book_approves_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `timezone`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'yaseeno373@gmail.com', 'yaseeno373@gmail.com', 'Egypt', NULL, '$2y$10$S3dvtgAE0L9C3/vH3WhsUOKtEvnUWunvbS67WOXrHUGU6Cjnszq2i', NULL, '2020-10-21 17:25:17', '2020-10-21 17:25:17');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
